# Build status

NOT TESTED on a hosted GitHub Actions runner. This update specifically removes the Android setup action that tried to install the unavailable SDK package `tools`.
The workflow locates an existing SDK manager and installs supported packages. A successful APK build remains unverified until the workflow runs in the user's repository.
