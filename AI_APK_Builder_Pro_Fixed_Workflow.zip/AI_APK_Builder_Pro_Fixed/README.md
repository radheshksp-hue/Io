# Fixed Android APK workflow

This workflow removes `android-actions/setup-android@v3`, which in the reported run attempted to install the obsolete SDK package `tools`.

It locates the runner's existing `sdkmanager` and installs only platform-tools, Android platform 35, and build-tools 35.0.0.

Copy `.github/workflows/build-apk.yml` into the same path in your GitHub repository. Then run it from Actions.

Important: this workflow has not been run against your repository. The APK build is only verified after a successful GitHub Actions run. Missing Gradle Wrapper JAR repair is limited to Gradle 8.13.
